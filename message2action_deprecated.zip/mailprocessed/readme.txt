This is an empty directory. It is used to save processed mails.
