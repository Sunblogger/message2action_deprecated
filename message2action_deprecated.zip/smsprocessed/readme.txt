This is an empty directory but should be present on your Pi.
