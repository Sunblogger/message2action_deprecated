This file is empty by default but should be present on your Pi.
